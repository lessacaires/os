<div id="sidebar">
<nav>
	<div class="menu">
		<span class="titulo">Navegação Paginas</span>
		<ul>
			<li>
				<a href="home">Home</a>
				<a href="logoff.php">Sair</a>
			</li>
		</ul>
		<ul>
			<span class="titulo">Navegação Admin</span>
			<li>
				<a href="<?php echo HOME ?>/categorias">Categorias</a>
				<a href="<?php echo HOME ?>/usuarios">Usuários</a>
				<a href="<?php echo HOME ?>/fornecedor">Fornecedores</a>
				<a href="<?php echo HOME ?>/ordem-de-servico">Ordens de Serviço</a>
			</li>
		</ul>
	</div>
</nav>
</div>	