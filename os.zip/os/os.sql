-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 05-Ago-2019 às 02:00
-- Versão do servidor: 5.7.24
-- versão do PHP: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `os`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `fornecedores`
--

DROP TABLE IF EXISTS `fornecedores`;
CREATE TABLE IF NOT EXISTS `fornecedores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(250) NOT NULL,
  `data` timestamp NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `servicos`
--

DROP TABLE IF EXISTS `servicos`;
CREATE TABLE IF NOT EXISTS `servicos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(250) NOT NULL,
  `solicitante` varchar(250) NOT NULL,
  `data_cad` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(1) NOT NULL,
  `descricao` text NOT NULL,
  `observacoes` text,
  `setor` varchar(250) NOT NULL,
  `data_mod` timestamp NULL DEFAULT NULL,
  `equipamento` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `servicos`
--

INSERT INTO `servicos` (`id`, `tipo`, `solicitante`, `data_cad`, `status`, `descricao`, `observacoes`, `setor`, `data_mod`, `equipamento`) VALUES
(1, 'Reparo', 'Marcelo', '2019-08-03 17:43:22', 1, 'Teste', 'Teste', 'DepÃ³sito', NULL, 'HidrÃ¡ulico'),
(2, 'ManutenÃ§Ã£o', 'Mario', '2019-08-05 00:56:22', 0, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras cursus quis felis vitae rutrum. Fusce ante nunc, vehicula et tortor id, congue vulputate orci. Aliquam eleifend, elit at dapibus condimentum, magna nibh iaculis felis, ut scelerisque libero mauris vitae purus. Nullam imperdiet turpis et bibendum tempor. Maecenas feugiat, massa ac semper commodo, diam ex finibus eros, bibendum dapibus risus elit nec dolor. In nulla eros, blandit sit amet risus euismod, finibus elementum ligula. Mauris vulputate aliquet auctor. Ut euismod bibendum risus euismod tristique. Ut dapibus luctus dapibus', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras cursus quis felis vitae rutrum. Fusce ante nunc, vehicula et tortor id, congue vulputate orci. Aliquam eleifend, elit at dapibus condimentum, magna nibh iaculis felis, ut scelerisque libero mauris vitae purus. Nullam imperdiet turpis et bibendum tempor. Maecenas feugiat, massa ac semper commodo, diam ex finibus eros, bibendum dapibus risus elit nec dolor. In nulla eros, blandit sit amet risus euismod, finibus elementum ligula. Mauris vulputate aliquet auctor. Ut euismod bibendum risus euismod tristique. Ut dapibus luctus dapibus', 'PerecÃ­veis', NULL, 'Freezer');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(250) NOT NULL,
  `senha` varchar(250) NOT NULL,
  `data_cad` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` double NOT NULL DEFAULT '1',
  `data_mod` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `senha`, `data_cad`, `status`, `data_mod`) VALUES
(1, 'lessacaires2019', '6c206cb7beda6ff19b4f21128d95fb6e', '2019-08-03 15:49:16', 1, '2019-08-05 04:59:17');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
