<div class="data">
		<h3>Lista de Fornecedores</h3>
		<a href="#" class="btn btn-primary">Cadastrar novo Fornecedor</a>
		<table border="0">
			<thead>
				<td>Nome</td>
				<td>Data Cadastro</td>
				<td>Status</td>
				<td colspan="3">Ações</td>
			</thead>
			<tbody>
				<tr>
					<td>Refritec</td>
					<td>31/07/2019</td>
					<td class="btn btn-success">Ativo</td>
					<td width="80"><a href="#" class="btn btn-dark">visulizar</a></td>
					<td width="80"><a href="#" class="btn btn-primary">editar</a></td>
					<td width="80"><a href="#" class="btn btn-danger">excluir</a></td>
				</tr>
			</tbody>
		</table>
	</div>
</div>