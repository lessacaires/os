<div class="categorias">
	<div class="box_categoria">
		<div class="icon">
			<a href="<?php echo URL::getBase();?>">
				<i class="fa fa-user-circle-o" aria-hidden="true"></i>
				<h4>Usuário</h4>
			</a>
		</div>
	</div>
	<div class="box_categoria">
		<div class="icon">
			<a href="<?php echo URL::getBase();?>">
				<i class="fa fa-truck" aria-hidden="true"></i>
				<h4>Fornecedor</h4>
			</a>
		</div>
	</div>
	<dir class="box_categoria">
		<div class="icon">
			<a href="<?php echo URL::getBase();?>">
				<i class="fa fa-wrench" aria-hidden="true"></i>
				<h4>Ordem de Serviço</h4>
			</a>
		</div>
	</dir>
</div>